handin_files = ['MkAStarCore.sml', 'MkBridges.sml', 'written.pdf']
lab_name = 'abridgedlab'
