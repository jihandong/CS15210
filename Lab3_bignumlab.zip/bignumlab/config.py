handin_files = ["MkBigNumAdd.sml", "MkBigNumMultiply.sml", "MkBigNumSubtract.sml", "written.pdf"]
lab_name = "bignumlab"
