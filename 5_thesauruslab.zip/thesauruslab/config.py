handin_files = ['MkAllShortestPaths.sml', 'MkThesaurusASP.sml', 'Tests.sml']
lab_name = 'thesauruslab'
