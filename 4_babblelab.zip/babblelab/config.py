handin_files = ["MkBabble.sml", "MkSeqUtil.sml", "MkTableKGramStats.sml", "corpus.txt", "Tests.sml", "written.pdf"]
lab_name = "babblelab"
